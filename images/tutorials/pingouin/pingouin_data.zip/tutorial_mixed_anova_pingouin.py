# Author: Raphael Vallat
# Date: April 2018
# Source code for the tutorial:
# https://raphaelvallat.github.io/pingouin.html
import numpy as np
import pandas as pd
import seaborn as sns
import pingouin as pg

# Define a seed to make the results reproducible
np.random.seed(1234)

# 1 - DATASET CREATION
# --------------------
months = ['August', 'January', 'June']

# Balanced design
n = 30
control = np.random.normal(5.5, size=len(months) * n)
meditation = np.r_[ np.random.normal(5.5, size=n),
                    np.random.normal(5.8, size=n),
                    np.random.normal(6.8, size=n) ]
df = pd.DataFrame({'Scores': np.r_[control, meditation],
					  'Time': np.r_[np.repeat(months, n), np.repeat(months, n)],
                   'Group': np.repeat(['Control', 'Meditation'], len(months) * n)})

# Unbalanced design
# n_control = 22
# n_medit = 19
# control = np.random.normal(5.5, size=len(months) * n_control)
# meditation = np.r_[ np.random.normal(5.5, size=n_medit),
#                     np.random.normal(5.8, size=n_medit),
#                     np.random.normal(6.8, size=n_medit) ]
#
# df = pd.DataFrame({'Scores': np.r_[control, meditation],
# 					  'Time': np.r_[np.repeat(months, n_control), np.repeat(months, n_medit)],
#                    'Group': np.repeat(np.r_[np.repeat('Control', n_control),
#                             np.repeat('Meditation', n_medit)], len(months)) })

# 2 - DESCRIPTIVE STATISTICS
# --------------------------
print(df.head())
print(df.groupby(['Time', 'Group']).agg(['mean', 'std']))

sns.set(font_scale=1.2)
sns.pointplot(data=df, x='Time', y='Scores', hue='Group', dodge=True,
              markers=['o', 's'], capsize=.1, errwidth=1, palette='colorblind')

# 3 - ANALYSIS OF VARIANCE
# ------------------------
aov = pg.mixed_anova(dv='Scores', within='Time', between='Group', data=df)
pg.print_table(aov)

# 4 - POST HOC TESTS
# ------------------
posthocs = pg.pairwise_ttests(dv='Scores', within='Time', between='Group',
                              effects='interaction', data=df)
pg.print_table(posthocs)
